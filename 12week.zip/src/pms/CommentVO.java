package pms;

public class CommentVO {

	private String commentId;
	private String taskDetailId;
	private String commentContent;
	private String commentDate;
	private String userId;
	public String getCommentId() {
		return commentId;
	}
	public void setCommentId(String commentId) {
		this.commentId = commentId;
	}
	public String getTaskDetailId() {
		return taskDetailId;
	}
	public void setTaskDetailId(String taskDetailId) {
		this.taskDetailId = taskDetailId;
	}
	public String getCommentContent() {
		return commentContent;
	}
	public void setCommentContent(String commentContent) {
		this.commentContent = commentContent;
	}
	public String getCommentDate() {
		return commentDate;
	}
	public void setCommentDate(String commentDate) {
		this.commentDate = commentDate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}

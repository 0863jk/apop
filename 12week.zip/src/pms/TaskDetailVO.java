package pms;

public class TaskDetailVO {
	private String taskDetailId;
	private String name;
	private String content;
	private String date;
	private String taskId;
	public String getTaskDetailId() {
		return taskDetailId;
	}
	public void setTaskDetailId(String taskDetailId) {
		this.taskDetailId = taskDetailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	
	
}
